# Catalogue auto et crash tests

API REST (FastAPI) et site web pour une base MySQL de modèles de voitures
(BMW, Peugeot, Volkswagen), leurs motorisations, leurs crash tests et un stock.

## Installation en local

1. Installer Python 3.10 ou plus récent, et MySQL ou MariaDB (par exemple XAMPP).
2. Créer la base et importer les données :
   ```
   mysql -u root -e "CREATE DATABASE `sql 2026` CHARACTER SET utf8mb4;"
   mysql -u root --default-character-set=utf8mb4 "sql 2026" < base/sql_2026.sql
   ```
3. Installer les dépendances :
   ```
   python -m pip install -r requirements.txt
   ```
4. Lancer le serveur :
   ```
   python -m uvicorn main:app --reload
   ```
5. Ouvrir http://127.0.0.1:8000/ (site) ou http://127.0.0.1:8000/docs (documentation de l'API).

## Configuration

La connexion à la base se règle avec des variables d'environnement.
Valeurs par défaut : `DB_HOST=localhost`, `DB_PORT=3306`, `DB_USER=root`,
`DB_PASSWORD=` (vide), `DB_NAME=sql 2026`.

## Attention

L'API n'a pas d'authentification : ne l'expose pas sur Internet sans la protéger.
