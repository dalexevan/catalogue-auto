"""
API REST + site web pour la base « sql 2026 »
Tables utilisées : marque, modele, motorisation, crashtest, vehicule_stock

Lancement (dans le dossier de ce fichier) :
    python -m pip install fastapi uvicorn pymysql
    python -m uvicorn main:app --reload

Site :              http://127.0.0.1:8000/
Documentation API : http://127.0.0.1:8000/docs
"""
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Literal, Optional

import pymysql
import pymysql.cursors
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

# ============================ CONFIGURATION ============================
# Les valeurs viennent des variables d'environnement (utile en ligne),
# sinon on utilise celles de XAMPP en local.
MYSQL = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),   # mets 3307 si XAMPP utilise un autre port
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "sql 2026"),
}
# =======================================================================

app = FastAPI(title="API catalogue auto et crash tests")


@contextmanager
def db():
    """Ouvre une connexion, valide (commit) à la fin ou annule en cas d'erreur."""
    conn = pymysql.connect(**MYSQL, charset="utf8mb4", cursorclass=pymysql.cursors.DictCursor)
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.exception_handler(pymysql.MySQLError)
async def erreur_mysql(request, exc):
    return JSONResponse(status_code=500, content={"detail": f"Erreur base de données : {exc}"})


# ------------------------------ Modèles de données ------------------------------
class ModeleIn(BaseModel):
    id_marque: int
    nom: str
    annee_debut: int
    annee_fin: Optional[int] = None


class MotorisationIn(BaseModel):
    libelle: str
    carburant: Optional[Literal["essence", "diesel", "hybride", "electrique"]] = None


class CrashIn(BaseModel):
    organisme: str = "Euro NCAP"
    annee_test: Optional[int] = None
    etoiles: Optional[int] = Field(None, ge=0, le=5)
    score_frontal: Optional[float] = None
    frontal_max: Optional[float] = None
    score_lateral: Optional[float] = None
    lateral_max: Optional[float] = None
    score_arriere: Optional[float] = None
    arriere_max: Optional[float] = None
    detail_frontal: Optional[str] = None
    detail_lateral: Optional[str] = None
    detail_arriere: Optional[str] = None


class StockIn(BaseModel):
    id_modele: int
    id_motorisation: Optional[int] = None
    etat: Literal["neuf", "occasion"]
    immatriculation: Optional[str] = None
    annee_mise_circ: Optional[int] = None
    kilometrage: Optional[int] = None
    prix: Optional[float] = None


# ------------------------------ Site ------------------------------
@app.get("/", include_in_schema=False)
def site():
    return FileResponse(Path(__file__).parent / "index.html")


# ------------------------------ Marques ------------------------------
@app.get("/api/marques")
def marques():
    with db() as cur:
        cur.execute(
            "SELECT ma.id_marque, ma.nom, COUNT(mo.id_modele) AS nb_modeles "
            "FROM marque ma LEFT JOIN modele mo ON mo.id_marque = ma.id_marque "
            "GROUP BY ma.id_marque, ma.nom ORDER BY ma.nom"
        )
        return cur.fetchall()


# ------------------------------ Modèles ------------------------------
@app.get("/api/modeles")
def lister_modeles(q: str = "", id_marque: int = 0, avec_crashtest: bool = False,
                   limit: int = 500, offset: int = 0):
    where, params = [], []
    if q:
        where.append("(mo.nom LIKE %s OR ma.nom LIKE %s)")
        params += [f"%{q}%"] * 2
    if id_marque:
        where.append("mo.id_marque = %s")
        params.append(id_marque)
    if avec_crashtest:
        where.append("EXISTS (SELECT 1 FROM crashtest c WHERE c.id_modele = mo.id_modele)")
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    with db() as cur:
        cur.execute(
            "SELECT mo.id_modele, mo.id_marque, ma.nom AS marque, mo.nom AS modele, "
            "mo.annee_debut, mo.annee_fin, "
            "(SELECT COUNT(*) FROM motorisation mt WHERE mt.id_modele = mo.id_modele) AS nb_motorisations, "
            "(SELECT COUNT(*) FROM crashtest c WHERE c.id_modele = mo.id_modele) AS nb_crash, "
            "(SELECT MAX(c.etoiles) FROM crashtest c WHERE c.id_modele = mo.id_modele) AS etoiles "
            "FROM modele mo JOIN marque ma ON ma.id_marque = mo.id_marque "
            f"{clause} ORDER BY ma.nom, mo.annee_debut, mo.id_modele LIMIT %s OFFSET %s",
            (*params, limit, offset),
        )
        return cur.fetchall()


@app.get("/api/modeles/{id_modele}")
def lire_modele(id_modele: int):
    with db() as cur:
        cur.execute(
            "SELECT mo.*, ma.nom AS marque FROM modele mo "
            "JOIN marque ma ON ma.id_marque = mo.id_marque WHERE mo.id_modele = %s",
            (id_modele,),
        )
        modele = cur.fetchone()
        if modele is None:
            raise HTTPException(404, "Modèle introuvable")
        cur.execute("SELECT * FROM motorisation WHERE id_modele = %s ORDER BY id_motorisation", (id_modele,))
        modele["motorisations"] = cur.fetchall()
        cur.execute("SELECT * FROM crashtest WHERE id_modele = %s LIMIT 1", (id_modele,))
        modele["crashtest"] = cur.fetchone()
        return modele


@app.get("/api/modeles/{id_modele}/motorisations")
def motorisations_du_modele(id_modele: int):
    with db() as cur:
        cur.execute("SELECT * FROM motorisation WHERE id_modele = %s ORDER BY id_motorisation", (id_modele,))
        return cur.fetchall()


@app.post("/api/modeles", status_code=201)
def creer_modele(m: ModeleIn):
    with db() as cur:
        try:
            cur.execute(
                "INSERT INTO modele (id_marque, nom, annee_debut, annee_fin) VALUES (%s, %s, %s, %s)",
                (m.id_marque, m.nom, m.annee_debut, m.annee_fin),
            )
        except pymysql.err.IntegrityError:
            raise HTTPException(400, "Ce modèle existe déjà pour cette marque, ou la marque est inconnue.")
        return {"id_modele": cur.lastrowid, **m.model_dump()}


@app.put("/api/modeles/{id_modele}")
def modifier_modele(id_modele: int, m: ModeleIn):
    with db() as cur:
        try:
            cur.execute(
                "UPDATE modele SET id_marque=%s, nom=%s, annee_debut=%s, annee_fin=%s WHERE id_modele=%s",
                (m.id_marque, m.nom, m.annee_debut, m.annee_fin, id_modele),
            )
        except pymysql.err.IntegrityError:
            raise HTTPException(400, "Ce modèle existe déjà pour cette marque, ou la marque est inconnue.")
        cur.execute("SELECT 1 FROM modele WHERE id_modele = %s", (id_modele,))
        if cur.fetchone() is None:
            raise HTTPException(404, "Modèle introuvable")
        return {"id_modele": id_modele, **m.model_dump()}


@app.delete("/api/modeles/{id_modele}")
def supprimer_modele(id_modele: int):
    with db() as cur:
        try:
            # les motorisations et le crash test sont supprimés avec le modèle (ON DELETE CASCADE)
            cur.execute("DELETE FROM modele WHERE id_modele = %s", (id_modele,))
        except pymysql.err.IntegrityError:
            raise HTTPException(409, "Suppression impossible : des véhicules en stock utilisent ce modèle.")
        if cur.rowcount == 0:
            raise HTTPException(404, "Modèle introuvable")
        return {"supprime": id_modele}


# ------------------------------ Motorisations ------------------------------
@app.post("/api/modeles/{id_modele}/motorisations", status_code=201)
def ajouter_motorisation(id_modele: int, m: MotorisationIn):
    with db() as cur:
        try:
            cur.execute(
                "INSERT INTO motorisation (id_modele, libelle, carburant) VALUES (%s, %s, %s)",
                (id_modele, m.libelle, m.carburant),
            )
        except pymysql.err.IntegrityError:
            raise HTTPException(400, "Cette motorisation existe déjà pour ce modèle, ou le modèle est inconnu.")
        return {"id_motorisation": cur.lastrowid, "id_modele": id_modele, **m.model_dump()}


@app.delete("/api/motorisations/{id_motorisation}")
def supprimer_motorisation(id_motorisation: int):
    with db() as cur:
        cur.execute("DELETE FROM motorisation WHERE id_motorisation = %s", (id_motorisation,))
        if cur.rowcount == 0:
            raise HTTPException(404, "Motorisation introuvable")
        return {"supprime": id_motorisation}


# ------------------------------ Crash tests ------------------------------
CRASH_COLS = ["organisme", "annee_test", "etoiles", "score_frontal", "frontal_max",
              "score_lateral", "lateral_max", "score_arriere", "arriere_max",
              "detail_frontal", "detail_lateral", "detail_arriere"]


@app.put("/api/modeles/{id_modele}/crashtest")
def enregistrer_crashtest(id_modele: int, c: CrashIn):
    valeurs = [getattr(c, col) for col in CRASH_COLS]
    with db() as cur:
        cur.execute("SELECT 1 FROM modele WHERE id_modele = %s", (id_modele,))
        if cur.fetchone() is None:
            raise HTTPException(404, "Modèle introuvable")
        cur.execute("SELECT id_crashtest FROM crashtest WHERE id_modele = %s LIMIT 1", (id_modele,))
        existant = cur.fetchone()
        if existant:
            sets = ", ".join(f"{col} = %s" for col in CRASH_COLS)
            cur.execute(f"UPDATE crashtest SET {sets} WHERE id_crashtest = %s",
                        (*valeurs, existant["id_crashtest"]))
        else:
            cols = ", ".join(CRASH_COLS)
            marqueurs = ", ".join(["%s"] * (len(CRASH_COLS) + 1))
            cur.execute(f"INSERT INTO crashtest ({cols}, id_modele) VALUES ({marqueurs})",
                        (*valeurs, id_modele))
        return {"id_modele": id_modele, **c.model_dump()}


@app.delete("/api/modeles/{id_modele}/crashtest")
def supprimer_crashtest(id_modele: int):
    with db() as cur:
        cur.execute("DELETE FROM crashtest WHERE id_modele = %s", (id_modele,))
        return {"supprime": cur.rowcount}


# ------------------------------ Stock de véhicules ------------------------------
@app.get("/api/stock")
def lister_stock(etat: str = ""):
    where, params = "", ()
    if etat in ("neuf", "occasion"):
        where, params = "WHERE s.etat = %s", (etat,)
    with db() as cur:
        cur.execute(
            "SELECT s.*, ma.nom AS marque, mo.nom AS modele, mt.libelle AS motorisation "
            "FROM vehicule_stock s "
            "JOIN modele mo ON mo.id_modele = s.id_modele "
            "JOIN marque ma ON ma.id_marque = mo.id_marque "
            f"LEFT JOIN motorisation mt ON mt.id_motorisation = s.id_motorisation {where} "
            "ORDER BY s.id_vehicule DESC",
            params,
        )
        return cur.fetchall()


@app.post("/api/stock", status_code=201)
def ajouter_stock(s: StockIn):
    with db() as cur:
        try:
            cur.execute(
                "INSERT INTO vehicule_stock (id_modele, id_motorisation, etat, immatriculation, "
                "annee_mise_circ, kilometrage, prix) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (s.id_modele, s.id_motorisation, s.etat, s.immatriculation,
                 s.annee_mise_circ, s.kilometrage, s.prix),
            )
        except pymysql.err.IntegrityError:
            raise HTTPException(400, "Immatriculation déjà utilisée, ou modèle / motorisation inconnu.")
        return {"id_vehicule": cur.lastrowid, **s.model_dump()}


@app.delete("/api/stock/{id_vehicule}")
def supprimer_stock(id_vehicule: int):
    with db() as cur:
        cur.execute("DELETE FROM vehicule_stock WHERE id_vehicule = %s", (id_vehicule,))
        if cur.rowcount == 0:
            raise HTTPException(404, "Véhicule introuvable")
        return {"supprime": id_vehicule}
